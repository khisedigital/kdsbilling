const { Op } = require('sequelize');
const { v4: uuidv4 } = require('uuid');
const AppError = require('../utils/AppError');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const { MOVEMENT_TYPES, toDecimal, getOrCreateBalance, applyStockMovement } = require('./stockEngine');

const productIncludes = (db) => [
  { model: db.Category, as: 'category', attributes: ['id', 'name'] },
  { model: db.Brand, as: 'brand', attributes: ['id', 'name'] },
  { model: db.UnitOfMeasure, as: 'uom', attributes: ['id', 'code', 'name', 'type'] },
  { model: db.TaxGroup, as: 'taxGroup', attributes: ['id', 'name', 'total_rate'] },
  {
    model: db.ProductVariant,
    as: 'variants',
    where: { deleted_at: null },
    required: false,
    include: [
      { model: db.UnitOfMeasure, as: 'uom', attributes: ['id', 'code', 'name'] },
      { model: db.TaxGroup, as: 'taxGroup', attributes: ['id', 'name', 'total_rate'] },
      { model: db.Barcode, as: 'barcodes' },
    ],
  },
  { model: db.ProductImage, as: 'images', separate: true, order: [['sort_order', 'ASC']] },
];

/** Lighter includes for list views (skip images). */
const productListIncludes = (db) => [
  { model: db.Category, as: 'category', attributes: ['id', 'name'] },
  { model: db.Brand, as: 'brand', attributes: ['id', 'name'] },
  { model: db.UnitOfMeasure, as: 'uom', attributes: ['id', 'code', 'name', 'type'] },
  { model: db.TaxGroup, as: 'taxGroup', attributes: ['id', 'name', 'total_rate'] },
  {
    model: db.ProductVariant,
    as: 'variants',
    where: { deleted_at: null },
    required: false,
    include: [
      { model: db.Barcode, as: 'barcodes', attributes: ['id', 'barcode', 'is_primary'] },
    ],
  },
];

function generateSku(prefix = 'SKU') {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

/** Split total qty across N sizes. Remainder goes to the first sizes (pcs-friendly). */
function splitStockQuantity(total, count, allowDecimal = false) {
  const n = Math.max(0, count);
  if (n === 0) return [];
  const qty = toDecimal(total) || 0;
  if (qty <= 0) return Array.from({ length: n }, () => 0);

  if (!allowDecimal) {
    const whole = Math.round(qty);
    const base = Math.floor(whole / n);
    let rem = whole - base * n;
    return Array.from({ length: n }, () => {
      const share = base + (rem > 0 ? 1 : 0);
      if (rem > 0) rem -= 1;
      return share;
    });
  }

  const base = Math.floor((qty / n) * 1000) / 1000;
  const shares = Array.from({ length: n }, () => base);
  shares[0] = toDecimal(qty - base * (n - 1));
  return shares;
}

async function setVariantStockQty(db, {
  branchId,
  variantId,
  targetQty,
  userId,
  productId,
  notes,
}, transaction) {
  const target = toDecimal(targetQty) || 0;
  const balance = await getOrCreateBalance(db, branchId, variantId, transaction);
  const current = toDecimal(balance.quantity) || 0;
  const change = toDecimal(target - current);
  if (change === 0) return;

  if (userId) {
    await applyStockMovement(
      db,
      {
        branchId,
        variantId,
        quantityChange: change,
        movementType: MOVEMENT_TYPES.ADJUSTMENT,
        referenceType: 'product_size_split',
        referenceId: productId || null,
        notes: notes || 'Stock split across sizes',
        userId,
        allowNegative: true,
      },
      transaction
    );
  } else {
    await balance.update({ quantity: target }, { transaction });
  }
}

/**
 * After size variants change, divide each branch's existing product stock
 * evenly across the kept sizes (or apply explicit stockQty for one branch).
 */
async function redistributeVariantStock(db, {
  product,
  existingVariantIds,
  keptVariants,
  incomingVariants,
  branchId,
  userId,
}, transaction) {
  const { StockBalance } = db;
  if (!keptVariants.length) return;

  const allowDecimal = !!(product.allow_decimal_qty || product.is_weight_based);
  const oldIds = existingVariantIds.filter(Boolean);
  if (!oldIds.length && !incomingVariants.some((v) => v.stockQty !== undefined)) return;

  const balances = oldIds.length
    ? await StockBalance.findAll({
        where: { variant_id: { [Op.in]: oldIds } },
        transaction,
        lock: transaction.LOCK.UPDATE,
      })
    : [];

  const branchTotals = new Map();
  for (const row of balances) {
    const qty = toDecimal(row.quantity) || 0;
    if (!qty) continue;
    branchTotals.set(row.branch_id, toDecimal((branchTotals.get(row.branch_id) || 0) + qty));
  }

  const hasExplicit =
    !!branchId &&
    incomingVariants.length === keptVariants.length &&
    incomingVariants.every((v) => v.stockQty !== undefined && v.stockQty !== null);

  const sizeSetChanged =
    oldIds.length !== keptVariants.length ||
    keptVariants.some((v) => !oldIds.includes(v.id)) ||
    oldIds.some((id) => !keptVariants.some((v) => v.id === id));

  // Nothing to do if sizes unchanged and no explicit stock payload
  if (!sizeSetChanged && !hasExplicit) return;

  // Ensure every branch that had stock (or the current branch for explicit qty) is covered
  if (hasExplicit && !branchTotals.has(branchId)) {
    branchTotals.set(branchId, 0);
  }

  if (!branchTotals.size && !hasExplicit) return;

  const branchIds = new Set([...branchTotals.keys()]);
  if (hasExplicit) branchIds.add(branchId);

  for (const bId of branchIds) {
    let targets;
    if (hasExplicit && bId === branchId) {
      targets = incomingVariants.map((v) => toDecimal(v.stockQty) || 0);
    } else {
      const total = branchTotals.get(bId) || 0;
      if (!sizeSetChanged || total <= 0) continue;
      targets = splitStockQuantity(total, keptVariants.length, allowDecimal);
    }

    // Zero stock on variants that will be removed (still active until soft-delete)
    for (const oldId of oldIds) {
      if (keptVariants.some((v) => v.id === oldId)) continue;
      await setVariantStockQty(
        db,
        {
          branchId: bId,
          variantId: oldId,
          targetQty: 0,
          userId,
          productId: product.id,
          notes: 'Stock moved while splitting sizes',
        },
        transaction
      );
    }

    for (let i = 0; i < keptVariants.length; i++) {
      await setVariantStockQty(
        db,
        {
          branchId: bId,
          variantId: keptVariants[i].id,
          targetQty: targets[i] ?? 0,
          userId,
          productId: product.id,
          notes: 'Stock split across sizes',
        },
        transaction
      );
    }
  }
}

async function listProducts(db, query, branchId = null) {
  const { Product } = db;
  const { page, limit, offset } = getPagination(query);
  const where = { deleted_at: null };

  if (query.status) where.status = query.status;
  if (query.categoryId) where.category_id = query.categoryId;
  if (query.brandId) where.brand_id = query.brandId;
  if (query.search) {
    where[Op.or] = [
      { name: { [Op.like]: `%${query.search}%` } },
      { tax_code: { [Op.like]: `%${query.search}%` } },
    ];
  }

  const { rows, count } = await Product.findAndCountAll({
    where,
    include: productListIncludes(db),
    order: [['created_at', 'DESC']],
    limit,
    offset,
    distinct: true,
  });

  const items = await attachProductStock(db, rows, branchId);
  return paginatedResponse(items, count, { page, limit });
}

async function attachProductStock(db, products, branchId) {
  if (!products?.length) return products || [];

  const plain = products.map((p) => (typeof p.toJSON === 'function' ? p.toJSON() : { ...p }));
  if (!branchId) {
    return plain.map((p) => ({
      ...p,
      stockQty: 0,
      variants: (p.variants || []).map((v) => ({ ...v, stockQty: 0 })),
    }));
  }

  const variantIds = plain.flatMap((p) => (p.variants || []).map((v) => v.id)).filter(Boolean);
  const balances = variantIds.length
    ? await db.StockBalance.findAll({
        where: {
          branch_id: branchId,
          variant_id: { [Op.in]: variantIds },
        },
        attributes: ['variant_id', 'quantity'],
      })
    : [];

  const stockByVariant = new Map(
    balances.map((b) => [b.variant_id, parseFloat(b.quantity) || 0])
  );

  return plain.map((product) => {
    const variants = (product.variants || []).map((v) => ({
      ...v,
      stockQty: stockByVariant.get(v.id) ?? 0,
    }));
    const stockQty = variants.reduce((sum, v) => sum + (v.stockQty || 0), 0);
    return { ...product, variants, stockQty };
  });
}

async function getProduct(db, id, branchId = null) {
  const { Product } = db;
  const product = await Product.findOne({
    where: { id, deleted_at: null },
    include: productIncludes(db),
  });
  if (!product) throw new AppError('Product not found', 404, 'NOT_FOUND');
  const [withStock] = await attachProductStock(db, [product], branchId);
  return withStock;
}

async function createVariantRecords(db, product, variants, transaction) {
  const { ProductVariant, Barcode } = db;
  const created = [];

  for (const v of variants) {
    const sku = v.sku?.trim() || generateSku();
    const variant = await ProductVariant.create(
      {
        product_id: product.id,
        sku,
        size: v.size || null,
        color: v.color || null,
        cost_price: v.costPrice ?? 0,
        selling_price: v.sellingPrice,
        mrp: v.mrp ?? null,
        wholesale_price: v.wholesalePrice ?? null,
        uom_id: v.uomId || product.uom_id,
        tax_group_id: v.taxGroupId || product.tax_group_id,
        reorder_level: v.reorderLevel ?? 0,
        status: v.status || 'active',
      },
      { transaction }
    );

    const barcodes = v.barcodes?.length ? v.barcodes : v.barcode ? [v.barcode] : [];
    for (let i = 0; i < barcodes.length; i++) {
      await Barcode.create(
        {
          variant_id: variant.id,
          barcode: String(barcodes[i]).trim(),
          is_primary: i === 0,
        },
        { transaction }
      );
    }

    created.push(variant);
  }

  return created;
}

async function createProduct(db, data, options = {}) {
  const { Product, UnitOfMeasure } = db;

  if (!data.name?.trim()) throw new AppError('Product name is required', 400, 'VALIDATION_ERROR');
  if (!data.uomId) throw new AppError('Unit of measure is required', 400, 'VALIDATION_ERROR');

  const uom = await UnitOfMeasure.findByPk(data.uomId);
  if (!uom) throw new AppError('Invalid unit of measure', 400, 'VALIDATION_ERROR');

  const variants = data.variants?.length ? data.variants : null;
  if (!variants?.length && data.sellingPrice === undefined) {
    throw new AppError('Selling price is required for single-variant product', 400, 'VALIDATION_ERROR');
  }

  const transaction = await db.sequelize.transaction();
  try {
    const product = await Product.create(
      {
        name: data.name.trim(),
        description: data.description || null,
        category_id: data.categoryId || null,
        brand_id: data.brandId || null,
        uom_id: data.uomId,
        tax_group_id: data.taxGroupId || null,
        tax_code: data.taxCode || null,
        is_weight_based: data.isWeightBased ?? (uom.type === 'weight' || uom.type === 'volume'),
        allow_decimal_qty: data.allowDecimalQty ?? uom.type !== 'count',
        has_variants: Boolean(variants?.length > 1 || (variants?.length === 1 && (variants[0].size || variants[0].color))),
        status: data.status || 'active',
      },
      { transaction }
    );

    const variantPayload = variants?.length
      ? variants
      : [
          {
            sku: data.sku,
            barcode: data.barcode,
            costPrice: data.costPrice,
            sellingPrice: data.sellingPrice,
            mrp: data.mrp,
            wholesalePrice: data.wholesalePrice,
            reorderLevel: data.reorderLevel,
            stockQty: data.stockQty,
          },
        ];

    const createdVariants = await createVariantRecords(db, product, variantPayload, transaction);

    const branchId = options.branchId || data.branchId || null;
    const userId = options.userId || data.userId || null;
    if (branchId) {
      for (let i = 0; i < createdVariants.length; i++) {
        const qty = variantPayload[i]?.stockQty;
        if (qty === undefined || qty === null) continue;
        const target = toDecimal(qty) || 0;
        if (target <= 0) continue;
        await setVariantStockQty(
          db,
          {
            branchId,
            variantId: createdVariants[i].id,
            targetQty: target,
            userId,
            productId: product.id,
            notes: 'Opening stock by size',
          },
          transaction
        );
      }
    }

    await transaction.commit();
    return getProduct(db, product.id, branchId);
  } catch (err) {
    await transaction.rollback();
    throw err;
  }
}

async function upsertVariantBarcode(db, variantId, barcodeValue, transaction) {
  const { Barcode } = db;
  const primary = await Barcode.findOne({
    where: { variant_id: variantId, is_primary: true },
    transaction,
  });

  if (barcodeValue) {
    if (primary) {
      await primary.update({ barcode: barcodeValue }, { transaction });
    } else {
      await Barcode.create(
        { variant_id: variantId, barcode: barcodeValue, is_primary: true },
        { transaction }
      );
    }
  } else if (primary) {
    await primary.destroy({ transaction });
  }
}

async function syncProductVariants(db, product, variants, transaction, options = {}) {
  const { ProductVariant } = db;
  if (!variants?.length) {
    throw new AppError('At least one size/variant is required', 400, 'VALIDATION_ERROR');
  }

  for (const v of variants) {
    const price = v.sellingPrice !== undefined ? parseFloat(v.sellingPrice) : null;
    if (price == null || Number.isNaN(price) || price < 0) {
      throw new AppError('Each size needs a valid selling price (0 allowed)', 400, 'VALIDATION_ERROR');
    }
  }

  const existing = await ProductVariant.findAll({
    where: { product_id: product.id, deleted_at: null },
    transaction,
  });
  const existingIds = existing.map((row) => row.id);
  const keptVariants = [];

  for (const v of variants) {
    if (v.id) {
      const variant = existing.find((row) => row.id === v.id);
      if (!variant) throw new AppError('Variant not found', 404, 'NOT_FOUND');

      await variant.update(
        {
          sku: v.sku?.trim() || variant.sku,
          size: v.size !== undefined ? v.size?.trim() || null : variant.size,
          color: v.color !== undefined ? v.color?.trim() || null : variant.color,
          cost_price: v.costPrice !== undefined ? v.costPrice : variant.cost_price,
          selling_price: v.sellingPrice,
          mrp: v.mrp !== undefined ? v.mrp : variant.mrp,
          wholesale_price: v.wholesalePrice !== undefined ? v.wholesalePrice : variant.wholesale_price,
          uom_id: v.uomId || product.uom_id,
          // Follow product tax when the payload does not override per variant,
          // so a new product tax rate applies on the next bill.
          tax_group_id:
            v.taxGroupId !== undefined ? v.taxGroupId || null : product.tax_group_id,
          reorder_level: v.reorderLevel !== undefined ? v.reorderLevel : variant.reorder_level,
        },
        { transaction }
      );

      if (v.barcode !== undefined) {
        await upsertVariantBarcode(db, variant.id, v.barcode?.trim() || null, transaction);
      }
      keptVariants.push(variant);
    } else {
      const [created] = await createVariantRecords(db, product, [v], transaction);
      keptVariants.push(created);
    }
  }

  await redistributeVariantStock(
    db,
    {
      product,
      existingVariantIds: existingIds,
      keptVariants,
      incomingVariants: variants,
      branchId: options.branchId || null,
      userId: options.userId || null,
    },
    transaction
  );

  const keepIds = new Set(keptVariants.map((v) => v.id));
  const now = new Date();
  for (const old of existing) {
    if (!keepIds.has(old.id)) {
      await old.update({ deleted_at: now, status: 'inactive' }, { transaction });
    }
  }

  await product.update(
    {
      has_variants: Boolean(
        variants.length > 1 || (variants.length === 1 && (variants[0].size || variants[0].color))
      ),
    },
    { transaction }
  );

  return keptVariants;
}

async function updateProduct(db, id, data, options = {}) {
  const { Product, ProductVariant } = db;
  const product = await Product.findOne({ where: { id, deleted_at: null } });
  if (!product) throw new AppError('Product not found', 404, 'NOT_FOUND');

  const transaction = await db.sequelize.transaction();
  try {
    const nextTaxGroupId = data.taxGroupId !== undefined ? data.taxGroupId || null : product.tax_group_id;

    await product.update({
      name: data.name?.trim() ?? product.name,
      description: data.description !== undefined ? data.description : product.description,
      category_id: data.categoryId !== undefined ? data.categoryId || null : product.category_id,
      brand_id: data.brandId !== undefined ? data.brandId || null : product.brand_id,
      uom_id: data.uomId ?? product.uom_id,
      tax_group_id: nextTaxGroupId,
      tax_code: data.taxCode !== undefined ? data.taxCode : product.tax_code,
      is_weight_based: data.isWeightBased ?? product.is_weight_based,
      allow_decimal_qty: data.allowDecimalQty ?? product.allow_decimal_qty,
      status: data.status ?? product.status,
    }, { transaction });

    if (Array.isArray(data.variants)) {
      await syncProductVariants(db, product, data.variants, transaction, {
        branchId: options.branchId || data.branchId || null,
        userId: options.userId || data.userId || null,
      });
    } else {
      // Keep every variant's tax in sync when the product tax group changes.
      if (data.taxGroupId !== undefined) {
        await ProductVariant.update(
          { tax_group_id: nextTaxGroupId },
          { where: { product_id: id, deleted_at: null }, transaction }
        );
      }

      const variantFields = [
        'variantId', 'sku', 'sellingPrice', 'costPrice', 'mrp', 'wholesalePrice', 'reorderLevel', 'barcode',
        'size', 'color',
      ];
      const hasVariantUpdate = variantFields.some((f) => data[f] !== undefined);

      if (hasVariantUpdate) {
        let variant = null;
        if (data.variantId) {
          variant = await ProductVariant.findOne({
            where: { id: data.variantId, product_id: id, deleted_at: null },
            transaction,
          });
        } else {
          variant = await ProductVariant.findOne({
            where: { product_id: id, deleted_at: null },
            order: [['created_at', 'ASC']],
            transaction,
          });
        }

        if (variant) {
          const variantUpdates = {};
          if (data.sku !== undefined) variantUpdates.sku = data.sku?.trim() || variant.sku;
          if (data.sellingPrice !== undefined) variantUpdates.selling_price = data.sellingPrice;
          if (data.costPrice !== undefined) variantUpdates.cost_price = data.costPrice;
          if (data.mrp !== undefined) variantUpdates.mrp = data.mrp;
          if (data.wholesalePrice !== undefined) variantUpdates.wholesale_price = data.wholesalePrice;
          if (data.reorderLevel !== undefined) variantUpdates.reorder_level = data.reorderLevel;
          if (data.uomId !== undefined) variantUpdates.uom_id = data.uomId;
          if (data.size !== undefined) variantUpdates.size = data.size?.trim() || null;
          if (data.color !== undefined) variantUpdates.color = data.color?.trim() || null;

          if (Object.keys(variantUpdates).length) {
            await variant.update(variantUpdates, { transaction });
          }

          if (data.barcode !== undefined) {
            await upsertVariantBarcode(db, variant.id, data.barcode?.trim() || null, transaction);
          }
        }
      }
    }

    await transaction.commit();
    return getProduct(db, id, options.branchId || null);
  } catch (err) {
    await transaction.rollback();
    throw err;
  }
}

async function deleteProduct(db, id) {
  const { Product, ProductVariant } = db;
  const product = await Product.findOne({ where: { id, deleted_at: null } });
  if (!product) throw new AppError('Product not found', 404, 'NOT_FOUND');

  const now = new Date();
  await product.update({ deleted_at: now, status: 'inactive' });
  await ProductVariant.update({ deleted_at: now, status: 'inactive' }, { where: { product_id: id } });
  return { deleted: true };
}

async function searchProducts(db, query, branchId = null) {
  const { Product, ProductVariant, Barcode } = db;
  const q = query.q?.trim();
  if (!q) throw new AppError('Search query is required', 400, 'VALIDATION_ERROR');

  const limit = parseInt(query.limit, 10) || 20;
  const productWhere = { deleted_at: null, status: 'active' };
  const variantBase = { deleted_at: null, status: 'active' };

  const barcodeExact = await Barcode.findOne({
    where: { barcode: q },
    include: [
      {
        model: ProductVariant,
        as: 'variant',
        where: variantBase,
        include: [{ model: Product, as: 'product', where: productWhere }],
      },
    ],
  });

  if (barcodeExact?.variant) {
    return attachStockQty(db, [await formatSearchResult(db, barcodeExact.variant)], branchId);
  }

  const barcodeMatches = await Barcode.findAll({
    where: { barcode: { [Op.like]: `%${q}%` } },
    include: [
      {
        model: ProductVariant,
        as: 'variant',
        where: variantBase,
        include: [
          {
            model: Product,
            as: 'product',
            where: productWhere,
          },
          { model: Barcode, as: 'barcodes' },
          { model: db.TaxGroup, as: 'taxGroup', attributes: ['id', 'name', 'total_rate'] },
          { model: db.UnitOfMeasure, as: 'uom', attributes: ['id', 'code', 'name', 'type'] },
        ],
      },
    ],
    limit,
  });

  if (barcodeMatches.length) {
    const seen = new Set();
    const results = [];
    for (const row of barcodeMatches) {
      if (!row.variant || seen.has(row.variant.id)) continue;
      seen.add(row.variant.id);
      results.push(await formatSearchResult(db, row.variant));
    }
    if (results.length) return attachStockQty(db, results, branchId);
  }

  const variants = await ProductVariant.findAll({
    where: {
      ...variantBase,
      [Op.or]: [
        { sku: { [Op.like]: `%${q}%` } },
        { size: { [Op.like]: `%${q}%` } },
        { color: { [Op.like]: `%${q}%` } },
        { '$product.name$': { [Op.like]: `%${q}%` } },
      ],
    },
    include: [
      {
        model: Product,
        as: 'product',
        where: productWhere,
        required: true,
      },
      { model: Barcode, as: 'barcodes' },
      { model: db.TaxGroup, as: 'taxGroup', attributes: ['id', 'name', 'total_rate'] },
      { model: db.UnitOfMeasure, as: 'uom', attributes: ['id', 'code', 'name', 'type'] },
    ],
    limit,
  });

  if (variants.length) {
    const results = await Promise.all(variants.map((v) => formatSearchResult(db, v)));
    return attachStockQty(db, results, branchId);
  }

  return [];
}

async function formatSearchResult(db, variant, productOverride = null) {
  const product = productOverride || variant.product || (await db.Product.findByPk(variant.product_id));
  return {
    variantId: variant.id,
    productId: product.id,
    productName: product.name,
    sku: variant.sku,
    size: variant.size,
    color: variant.color,
    sellingPrice: parseFloat(variant.selling_price),
    costPrice: parseFloat(variant.cost_price),
    mrp: variant.mrp ? parseFloat(variant.mrp) : null,
    barcodes: variant.barcodes?.map((b) => b.barcode) || [],
    taxGroup: variant.taxGroup || null,
    uom: variant.uom || null,
    isWeightBased: product.is_weight_based,
    allowDecimalQty: product.allow_decimal_qty,
    stockQty: 0,
  };
}

async function attachStockQty(db, results, branchId) {
  if (!results.length) return results;
  if (!branchId) return results;

  const balances = await db.StockBalance.findAll({
    where: {
      branch_id: branchId,
      variant_id: { [Op.in]: results.map((r) => r.variantId) },
    },
    attributes: ['variant_id', 'quantity'],
  });
  const byVariant = new Map(
    balances.map((b) => [b.variant_id, parseFloat(b.quantity) || 0])
  );

  return results.map((r) => ({
    ...r,
    stockQty: byVariant.has(r.variantId) ? byVariant.get(r.variantId) : 0,
  }));
}

async function bulkImport(db, rows) {
  if (!Array.isArray(rows) || !rows.length) {
    throw new AppError('Import rows array is required', 400, 'VALIDATION_ERROR');
  }

  const results = { success: 0, failed: 0, errors: [] };

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    try {
      const { Category, Brand, UnitOfMeasure } = db;

      let categoryId = null;
      if (row.category) {
        const [cat] = await Category.findOrCreate({
          where: { name: row.category, deleted_at: null },
          defaults: { id: uuidv4(), name: row.category, status: 'active' },
        });
        categoryId = cat.id;
      }

      let brandId = null;
      if (row.brand) {
        const [brand] = await Brand.findOrCreate({
          where: { name: row.brand, deleted_at: null },
          defaults: { id: uuidv4(), name: row.brand, status: 'active' },
        });
        brandId = brand.id;
      }

      const uomCode = row.uom || 'pcs';
      const uom = await UnitOfMeasure.findOne({ where: { code: uomCode } });
      if (!uom) throw new AppError(`Invalid UOM: ${uomCode}`, 400, 'VALIDATION_ERROR');

      await createProduct(db, {
        name: row.name,
        description: row.description,
        categoryId,
        brandId,
        uomId: uom.id,
        taxCode: row.taxCode,
        isWeightBased: row.isWeightBased,
        allowDecimalQty: row.allowDecimalQty,
        sku: row.sku,
        barcode: row.barcode,
        costPrice: row.costPrice,
        sellingPrice: row.sellingPrice,
        mrp: row.mrp,
        variants: row.variants,
      });

      results.success += 1;
    } catch (err) {
      results.failed += 1;
      results.errors.push({ row: i + 1, message: err.message });
    }
  }

  return results;
}

async function listTaxGroups(db) {
  const { TaxGroup, TaxGroupComponent, TaxType } = db;
  return TaxGroup.findAll({
    where: { status: 'active' },
    include: [
      {
        model: TaxGroupComponent,
        as: 'components',
        include: [{ model: TaxType, as: 'taxType', attributes: ['id', 'code', 'name'] }],
      },
    ],
    order: [['total_rate', 'ASC'], ['name', 'ASC']],
  });
}

async function listUnits(db) {
  const { UnitOfMeasure } = db;
  return UnitOfMeasure.findAll({ order: [['type', 'ASC'], ['name', 'ASC']] });
}

module.exports = {
  listProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  searchProducts,
  bulkImport,
  listTaxGroups,
  listUnits,
  generateSku,
};
