require('dotenv').config();

module.exports = {
  development: {
    username: process.env.TENANT_DB_USER || 'root',
    password: process.env.TENANT_DB_PASSWORD || '',
    database: process.env.TENANT_DB_NAME || 'billing_tenant_dev',
    host: process.env.TENANT_DB_HOST || 'localhost',
    port: parseInt(process.env.TENANT_DB_PORT, 10) || 3306,
    dialect: 'mysql',
    logging: console.log,
  },
};
