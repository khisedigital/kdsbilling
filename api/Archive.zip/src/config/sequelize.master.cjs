require('dotenv').config();
const config = require('./index');

module.exports = {
  development: {
    username: config.masterDb.username,
    password: config.masterDb.password,
    database: config.masterDb.database,
    host: config.masterDb.host,
    port: config.masterDb.port,
    dialect: 'mysql',
    logging: console.log,
  },
};
